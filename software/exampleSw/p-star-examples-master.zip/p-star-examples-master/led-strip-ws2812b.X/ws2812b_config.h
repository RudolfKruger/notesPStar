// This file defines parameters that are used by ws2812b.c.

#define WS2812B_DATA_TRIS TRISB
#define WS2812B_DATA_LAT  LATB
#define WS2812B_DATA_BIT  1
