#ifndef _SYSTEM_H
#define _SYSTEM_H

// This code is meant to run on a PIC running at 48 MHz.
#define _XTAL_FREQ 48000000

#endif
